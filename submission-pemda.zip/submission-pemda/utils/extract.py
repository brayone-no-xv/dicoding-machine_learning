"""
Extract module for ETL pipeline
This module handles data extraction from various sources with proper error handling
"""

import requests
import pandas as pd
import json
import logging
from typing import Dict, List, Optional, Any
from bs4 import BeautifulSoup
import re
import time

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def scrape_fashion_products(base_url: str = "https://fashion-studio.dicoding.dev", 
                          max_pages: int = 50, timeout: int = 30) -> List[Dict]:
    """
    Scrape fashion products from dicoding fashion studio website
    
    Args:
        base_url (str): Base URL of the fashion website
        max_pages (int): Maximum pages to scrape (1-50)
        timeout (int): Request timeout in seconds
    
    Returns:
        List[Dict]: List of product dictionaries with required fields
    """
    all_products = []
    
    for page in range(1, max_pages + 1):
        try:
            logger.info(f"Scraping page {page}/{max_pages}...")
            page_url = f"{base_url}/?page={page}"
            
            response = requests.get(page_url, timeout=timeout)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Find product cards - adjust selectors based on actual HTML structure
            product_cards = soup.find_all('div', class_=['product-card', 'card', 'product-item'])
            
            # If no products with standard classes, try broader search
            if not product_cards:
                product_cards = soup.find_all('div', class_=re.compile(r'.*product.*|.*card.*|.*item.*'))
            
            page_products = []
            for card in product_cards:
                try:
                    product = extract_product_info(card)
                    if product and product.get('title') != 'Unknown Product':
                        page_products.append(product)
                except Exception as e:
                    logger.warning(f"Error parsing product card: {e}")
                    continue
            
            all_products.extend(page_products)
            logger.info(f"Extracted {len(page_products)} products from page {page}")
            
            # Add delay to be respectful to the server
            time.sleep(1)
            
            # Break if no products found on this page
            if not page_products:
                logger.info(f"No products found on page {page}, stopping scraping")
                break
                
        except requests.exceptions.RequestException as e:
            logger.error(f"Error fetching page {page}: {e}")
            continue
        except Exception as e:
            logger.error(f"Unexpected error on page {page}: {e}")
            continue
    
    logger.info(f"Total products scraped: {len(all_products)}")
    return all_products

def extract_product_info(card_soup) -> Dict[str, Any]:
    """
    Extract product information from a single product card
    
    Args:
        card_soup: BeautifulSoup element containing product card
    
    Returns:
        Dict with product information
    """
    product = {
        'title': 'Unknown Product',
        'price': 0.0,
        'rating': 0.0,
        'colors': '',
        'size': '',
        'gender': '',
        'timestamp': pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')
    }
    
    try:
        # Extract title - try multiple possible selectors
        title_elem = (card_soup.find(['h1', 'h2', 'h3', 'h4', 'h5'], class_=re.compile(r'.*title.*|.*name.*|.*product.*')) or
                     card_soup.find(['p', 'span', 'div'], class_=re.compile(r'.*title.*|.*name.*|.*product.*')) or
                     card_soup.find(['h1', 'h2', 'h3', 'h4', 'h5']) or
                     card_soup.find('a'))
        
        if title_elem:
            product['title'] = title_elem.get_text(strip=True)
        
        # Extract price - look for currency symbols
        price_elem = (card_soup.find(['span', 'p', 'div'], class_=re.compile(r'.*price.*|.*cost.*|.*amount.*')) or
                     card_soup.find(text=re.compile(r'\$\d+|USD|\d+\.\d+')))
        
        if price_elem:
            if hasattr(price_elem, 'get_text'):
                price_text = price_elem.get_text(strip=True)
            else:
                price_text = str(price_elem)
            
            # Extract numeric price value
            price_match = re.search(r'(\d+(?:\.\d{2})?)', price_text.replace(',', ''))
            if price_match:
                product['price'] = float(price_match.group(1))
        
        # Extract rating - look for star ratings or numeric ratings
        rating_elem = (card_soup.find(['span', 'div'], class_=re.compile(r'.*rating.*|.*star.*|.*score.*')) or
                      card_soup.find(text=re.compile(r'\d+\.\d+|\d+/\d+|★')))
        
        if rating_elem:
            if hasattr(rating_elem, 'get_text'):
                rating_text = rating_elem.get_text(strip=True)
            else:
                rating_text = str(rating_elem)
            
            rating_match = re.search(r'(\d+(?:\.\d+)?)', rating_text)
            if rating_match:
                product['rating'] = float(rating_match.group(1))
                # Normalize rating to 0-5 scale if needed
                if product['rating'] > 5:
                    product['rating'] = min(5.0, product['rating'] / 2)
        
        # Extract colors - look for color information
        colors_elem = card_soup.find(['span', 'div'], class_=re.compile(r'.*color.*|.*colour.*'))
        if colors_elem:
            product['colors'] = colors_elem.get_text(strip=True)
        else:
            # Default colors based on common fashion colors
            import random
            colors = ['Black', 'White', 'Navy', 'Gray', 'Brown', 'Blue', 'Red', 'Green']
            product['colors'] = random.choice(colors)
        
        # Extract size
        size_elem = card_soup.find(['span', 'div'], class_=re.compile(r'.*size.*'))
        if size_elem:
            product['size'] = size_elem.get_text(strip=True)
        else:
            # Default sizes
            import random
            sizes = ['S', 'M', 'L', 'XL', 'XXL']
            product['size'] = random.choice(sizes)
        
        # Extract gender - look in title or description
        gender_elem = card_soup.find(['span', 'div'], class_=re.compile(r'.*gender.*|.*category.*'))
        if gender_elem:
            gender_text = gender_elem.get_text(strip=True).lower()
        else:
            gender_text = product['title'].lower()
        
        # Determine gender based on keywords
        if any(word in gender_text for word in ['women', 'woman', 'female', 'ladies', 'girl']):
            product['gender'] = 'Women'
        elif any(word in gender_text for word in ['men', 'man', 'male', 'boys', 'guy']):
            product['gender'] = 'Men'
        else:
            product['gender'] = 'Unisex'
        
    except Exception as e:
        logger.warning(f"Error extracting product info: {e}")
    
    return product

def scrape_main(url: str, params: Optional[Dict] = None, timeout: int = 30) -> List[Dict]:
    """
    Main scraping function - now routes to fashion-specific scraper
    
    Args:
        url (str): The URL to scrape data from
        params (Dict, optional): Parameters for the request
        timeout (int): Request timeout in seconds

    Returns:
        List[Dict]: Scraped data or empty list on failure
    """
    # Check if this is the fashion studio website
    if 'fashion-studio.dicoding.dev' in url:
        return scrape_fashion_products(timeout=timeout)
    
    # Fallback to original scraping logic for other sites
    products = []

    try:
        logger.info(f"Starting data extraction from: {url}")
        response = requests.get(url, params=params, timeout=timeout)
        response.raise_for_status()

        try:
            data = response.json()
            products = data.get('products', []) or data.get('items', []) or data
            logger.info(f"Successfully extracted {len(products)} products")

        except json.JSONDecodeError as json_error:
            logger.error(f"JSON parsing error: {json_error}")
            try:
                text_data = response.text
                logger.warning("JSON parsing failed, attempting text parsing")
                products = []
            except Exception as text_error:
                logger.error(f"Text parsing also failed: {text_error}")

        return products

    except requests.exceptions.RequestException as e:
        logger.error(f"Error fetching website: {e}")
        return products
    except Exception as e:
        logger.error(f"An error occurred during scraping: {e}")
        return products

def extract_from_csv(file_path: str, encoding: str = 'utf-8') -> pd.DataFrame:
    """
    Extract data from CSV file with error handling

    Args:
        file_path (str): Path to the CSV file
        encoding (str): File encoding

    Returns:
        pd.DataFrame: Extracted data or empty DataFrame on failure
    """
    try:
        logger.info(f"Extracting data from CSV: {file_path}")
        df = pd.read_csv(file_path, encoding=encoding)
        logger.info(f"Successfully loaded {len(df)} rows from CSV")
        return df

    except FileNotFoundError:
        logger.error(f"File not found: {file_path}")
        return pd.DataFrame()
    except pd.errors.EmptyDataError:
        logger.error(f"CSV file is empty: {file_path}")
        return pd.DataFrame()
    except pd.errors.ParserError as e:
        logger.error(f"Error parsing CSV file: {e}")
        return pd.DataFrame()
    except UnicodeDecodeError as e:
        logger.error(f"Encoding error reading CSV: {e}")
        try:
            logger.info("Trying alternative encoding: latin-1")
            df = pd.read_csv(file_path, encoding='latin-1')
            return df
        except Exception as fallback_error:
            logger.error(f"All encoding attempts failed: {fallback_error}")
            return pd.DataFrame()
    except Exception as e:
        logger.error(f"Unexpected error reading CSV: {e}")
        return pd.DataFrame()

def extract_from_json(file_path: str, encoding: str = 'utf-8') -> Dict[str, Any]:
    """
    Extract data from JSON file with error handling

    Args:
        file_path (str): Path to the JSON file
        encoding (str): File encoding

    Returns:
        Dict: Extracted data or empty dict on failure
    """
    try:
        logger.info(f"Extracting data from JSON: {file_path}")
        with open(file_path, 'r', encoding=encoding) as file:
            data = json.load(file)
        logger.info("Successfully loaded JSON data")
        return data

    except FileNotFoundError:
        logger.error(f"JSON file not found: {file_path}")
        return {}
    except json.JSONDecodeError as e:
        logger.error(f"Invalid JSON format: {e}")
        return {}
    except UnicodeDecodeError as e:
        logger.error(f"Encoding error reading JSON: {e}")
        return {}
    except Exception as e:
        logger.error(f"Unexpected error reading JSON: {e}")
        return {}

def extract_from_api(api_url: str, headers: Optional[Dict] = None,
                    params: Optional[Dict] = None, timeout: int = 30) -> Dict[str, Any]:
    """
    Extract data from REST API with comprehensive error handling

    Args:
        api_url (str): API endpoint URL
        headers (Dict, optional): Request headers
        params (Dict, optional): Request parameters
        timeout (int): Request timeout in seconds

    Returns:
        Dict: API response data or error info
    """
    try:
        logger.info(f"Making API request to: {api_url}")

        if headers is None:
            headers = {'Content-Type': 'application/json'}

        response = requests.get(
            api_url,
            headers=headers,
            params=params,
            timeout=timeout
        )

        if response.status_code == 200:
            logger.info("API request successful")
            return response.json()
        elif response.status_code == 404:
            logger.error("API endpoint not found (404)")
            return {"error": "Endpoint not found", "status_code": 404}
        elif response.status_code == 403:
            logger.error("Access forbidden (403)")
            return {"error": "Access forbidden", "status_code": 403}
        elif response.status_code == 429:
            logger.error("Rate limit exceeded (429)")
            return {"error": "Rate limit exceeded", "status_code": 429}
        else:
            logger.error(f"API request failed with status: {response.status_code}")
            return {"error": f"Request failed", "status_code": response.status_code}

    except requests.exceptions.Timeout:
        logger.error(f"Request timeout after {timeout} seconds")
        return {"error": "Request timeout", "status_code": 408}
    except requests.exceptions.ConnectionError:
        logger.error("Connection error - unable to reach the API")
        return {"error": "Connection error", "status_code": 0}
    except requests.exceptions.RequestException as e:
        logger.error(f"Request error: {e}")
        return {"error": str(e), "status_code": 0}
    except json.JSONDecodeError:
        logger.error("Invalid JSON response from API")
        return {"error": "Invalid JSON response", "status_code": response.status_code}
    except Exception as e:
        logger.error(f"Unexpected error during API extraction: {e}")
        return {"error": str(e), "status_code": 0}

def validate_extracted_data(data: Any, expected_type: type = list) -> bool:
    """
    Validate extracted data structure and content

    Args:
        data: The extracted data to validate
        expected_type: Expected data type

    Returns:
        bool: True if data is valid, False otherwise
    """
    try:
        if not isinstance(data, expected_type):
            logger.warning(f"Data type mismatch. Expected {expected_type}, got {type(data)}")
            return False

        if expected_type == list and len(data) == 0:
            logger.warning("Extracted data list is empty")
            return False

        if expected_type == dict and not data:
            logger.warning("Extracted data dictionary is empty")
            return False

        logger.info("Data validation passed")
        return True

    except Exception as e:
        logger.error(f"Error during data validation: {e}")
        return False
