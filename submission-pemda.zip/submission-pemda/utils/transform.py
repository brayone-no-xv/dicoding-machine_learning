"""
Transform module for ETL pipeline
This module handles data transformation with proper error handling
"""

import pandas as pd
import numpy as np
import logging
import re
from typing import Dict, List, Any, Optional, Union
from datetime import datetime

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def clean_text_data(data: Union[str, pd.Series], remove_special_chars: bool = True) -> Union[str, pd.Series]:
    """
    Clean text data by removing unwanted characters and normalizing format

    Args:
        data: Text data to clean (string or pandas Series)
        remove_special_chars: Whether to remove special characters

    Returns:
        Cleaned text data
    """
    try:
        logger.info("Starting text data cleaning")

        if isinstance(data, str):
            cleaned = data.strip()
            if remove_special_chars:
                cleaned = re.sub(r'[^\w\s\-\.]', '', cleaned)
            cleaned = re.sub(r'\s+', ' ', cleaned)
            return cleaned

        elif isinstance(data, pd.Series):
            cleaned_series = data.astype(str).str.strip()
            if remove_special_chars:
                cleaned_series = cleaned_series.str.replace(r'[^\w\s\-\.]', '', regex=True)
            cleaned_series = cleaned_series.str.replace(r'\s+', ' ', regex=True)
            logger.info(f"Cleaned {len(cleaned_series)} text entries")
            return cleaned_series

        else:
            logger.warning(f"Unsupported data type for cleaning: {type(data)}")
            return data

    except Exception as e:
        logger.error(f"Error during text cleaning: {e}")
        return data

def normalize_numeric_data(df: pd.DataFrame, numeric_columns: List[str]) -> pd.DataFrame:
    """
    Normalize numeric data with error handling

    Args:
        df: DataFrame containing the data
        numeric_columns: List of column names to normalize

    Returns:
        DataFrame with normalized numeric data
    """
    try:
        logger.info(f"Normalizing numeric columns: {numeric_columns}")
        df_copy = df.copy()

        for column in numeric_columns:
            if column not in df_copy.columns:
                logger.warning(f"Column '{column}' not found in DataFrame")
                continue

            try:
                df_copy[column] = pd.to_numeric(df_copy[column], errors='coerce')

                if df_copy[column].isna().sum() > 0:
                    logger.warning(f"Found {df_copy[column].isna().sum()} NaN values in column '{column}'")
                    median_value = df_copy[column].median()
                    df_copy[column].fillna(median_value, inplace=True)

                col_min = df_copy[column].min()
                col_max = df_copy[column].max()

                if col_max != col_min:
                    df_copy[column] = (df_copy[column] - col_min) / (col_max - col_min)
                else:
                    logger.warning(f"Column '{column}' has constant values, skipping normalization")

            except Exception as col_error:
                logger.error(f"Error normalizing column '{column}': {col_error}")
                continue

        logger.info("Numeric normalization completed")
        return df_copy

    except Exception as e:
        logger.error(f"Error during numeric normalization: {e}")
        return df

def handle_missing_values(df: pd.DataFrame, strategy: str = 'median',
                         custom_values: Optional[Dict[str, Any]] = None) -> pd.DataFrame:
    """
    Handle missing values in DataFrame with multiple strategies

    Args:
        df: DataFrame to process
        strategy: Strategy for handling missing values ('median', 'mean', 'mode', 'drop', 'custom')
        custom_values: Dictionary of column names and their replacement values

    Returns:
        DataFrame with handled missing values
    """
    try:
        logger.info(f"Handling missing values using strategy: {strategy}")
        df_copy = df.copy()

        missing_counts = df_copy.isnull().sum()
        total_missing = missing_counts.sum()

        if total_missing == 0:
            logger.info("No missing values found")
            return df_copy

        logger.info(f"Found {total_missing} missing values across {(missing_counts > 0).sum()} columns")

        if strategy == 'drop':
            df_copy.dropna(inplace=True)
            logger.info(f"Dropped rows with missing values. New shape: {df_copy.shape}")

        elif strategy == 'custom' and custom_values:
            for column, value in custom_values.items():
                if column in df_copy.columns:
                    df_copy[column].fillna(value, inplace=True)
                    logger.info(f"Filled missing values in '{column}' with custom value: {value}")

        else:
            for column in df_copy.columns:
                if df_copy[column].isnull().sum() > 0:
                    try:
                        if df_copy[column].dtype in ['int64', 'float64']:
                            if strategy == 'median':
                                fill_value = df_copy[column].median()
                            elif strategy == 'mean':
                                fill_value = df_copy[column].mean()
                            else:
                                fill_value = df_copy[column].mode().iloc[0] if not df_copy[column].mode().empty else 0
                        else:
                            mode_values = df_copy[column].mode()
                            fill_value = mode_values.iloc[0] if not mode_values.empty else 'Unknown'

                        df_copy[column].fillna(fill_value, inplace=True)
                        logger.info(f"Filled missing values in '{column}' with {strategy}: {fill_value}")

                    except Exception as col_error:
                        logger.error(f"Error handling missing values in column '{column}': {col_error}")
                        fallback_value = 0 if df_copy[column].dtype in ['int64', 'float64'] else 'Unknown'
                        df_copy[column].fillna(fallback_value, inplace=True)

        final_missing = df_copy.isnull().sum().sum()
        logger.info(f"Missing values after processing: {final_missing}")
        return df_copy

    except Exception as e:
        logger.error(f"Error handling missing values: {e}")
        return df

def standardize_date_format(df: pd.DataFrame, date_columns: List[str],
                          target_format: str = '%Y-%m-%d') -> pd.DataFrame:
    """
    Standardize date formats across specified columns

    Args:
        df: DataFrame containing date columns
        date_columns: List of column names containing dates
        target_format: Target date format string

    Returns:
        DataFrame with standardized date formats
    """
    try:
        logger.info(f"Standardizing date format for columns: {date_columns}")
        df_copy = df.copy()

        for column in date_columns:
            if column not in df_copy.columns:
                logger.warning(f"Date column '{column}' not found in DataFrame")
                continue

            try:
                df_copy[column] = pd.to_datetime(df_copy[column], errors='coerce')

                failed_parsing = df_copy[column].isnull().sum()
                if failed_parsing > 0:
                    logger.warning(f"Failed to parse {failed_parsing} dates in column '{column}'")

                df_copy[column] = df_copy[column].dt.strftime(target_format)
                logger.info(f"Successfully standardized dates in column '{column}'")

            except Exception as col_error:
                logger.error(f"Error standardizing dates in column '{column}': {col_error}")
                continue

        return df_copy

    except Exception as e:
        logger.error(f"Error during date standardization: {e}")
        return df

def remove_duplicates(df: pd.DataFrame, subset: Optional[List[str]] = None,
                     keep: str = 'first') -> pd.DataFrame:
    """
    Remove duplicate records with error handling

    Args:
        df: DataFrame to process
        subset: Column names to consider for identifying duplicates
        keep: Which duplicates to keep ('first', 'last', False)

    Returns:
        DataFrame without duplicates
    """
    try:
        logger.info("Removing duplicate records")
        initial_count = len(df)

        df_cleaned = df.drop_duplicates(subset=subset, keep=keep)

        duplicates_removed = initial_count - len(df_cleaned)
        logger.info(f"Removed {duplicates_removed} duplicate records. New count: {len(df_cleaned)}")

        return df_cleaned

    except Exception as e:
        logger.error(f"Error removing duplicates: {e}")
        return df

def convert_usd_to_idr(df: pd.DataFrame, price_column: str = 'price', 
                      exchange_rate: float = 16000.0) -> pd.DataFrame:
    """
    Convert USD prices to IDR (Indonesian Rupiah)
    
    Args:
        df: DataFrame containing price data
        price_column: Name of the price column
        exchange_rate: USD to IDR exchange rate (default: 16,000)
    
    Returns:
        DataFrame with converted prices
    """
    try:
        if price_column not in df.columns:
            logger.warning(f"Price column '{price_column}' not found")
            return df
        
        logger.info(f"Converting USD to IDR using exchange rate: {exchange_rate}")
        
        # Convert to numeric if not already
        df[price_column] = pd.to_numeric(df[price_column], errors='coerce')
        
        # Convert USD to IDR
        df[price_column] = df[price_column] * exchange_rate
        
        # Round to 2 decimal places
        df[price_column] = df[price_column].round(2)
        
        logger.info(f"Successfully converted prices to IDR")
        return df
        
    except Exception as e:
        logger.error(f"Error converting USD to IDR: {e}")
        return df

def remove_invalid_products(df: pd.DataFrame, title_column: str = 'title',
                           invalid_values: List[str] = None) -> pd.DataFrame:
    """
    Remove products with invalid or placeholder data
    
    Args:
        df: DataFrame to clean
        title_column: Name of the title/name column
        invalid_values: List of values to consider invalid
    
    Returns:
        DataFrame with invalid products removed
    """
    try:
        if invalid_values is None:
            invalid_values = ['Unknown Product', 'N/A', 'NULL', '', 'undefined', 
                             'placeholder', 'test product', 'sample product']
        
        initial_count = len(df)
        
        if title_column in df.columns:
            # Remove rows with invalid titles (case-insensitive)
            mask = ~df[title_column].astype(str).str.lower().isin([v.lower() for v in invalid_values])
            df = df[mask]
            
            # Remove rows where title is just whitespace or very short
            df = df[df[title_column].astype(str).str.strip().str.len() > 2]
        
        removed_count = initial_count - len(df)
        logger.info(f"Removed {removed_count} invalid products")
        
        return df
        
    except Exception as e:
        logger.error(f"Error removing invalid products: {e}")
        return df

def clean_fashion_data(df: pd.DataFrame) -> pd.DataFrame:
    """
    Comprehensive cleaning function for fashion product data
    
    Args:
        df: DataFrame containing fashion product data
    
    Returns:
        Cleaned DataFrame
    """
    try:
        logger.info("Starting comprehensive fashion data cleaning")
        initial_shape = df.shape
        
        # 1. Remove completely null rows
        df = df.dropna(how='all')
        
        # 2. Remove invalid products
        df = remove_invalid_products(df)
        
        # 3. Convert USD to IDR
        df = convert_usd_to_idr(df)
        
        # 4. Remove duplicates based on title (case-insensitive)
        if 'title' in df.columns:
            # Create a temporary column for case-insensitive comparison
            df['_temp_title_lower'] = df['title'].astype(str).str.lower().str.strip()
            df = df.drop_duplicates(subset=['_temp_title_lower'], keep='first')
            df = df.drop(columns=['_temp_title_lower'])
        
        # 5. Clean text columns
        text_columns = ['title', 'colors', 'size', 'gender']
        for col in text_columns:
            if col in df.columns:
                df[col] = clean_text_data(df[col])
        
        # 6. Handle missing values with appropriate strategies
        # Fill missing prices with median
        if 'price' in df.columns:
            median_price = df['price'].median()
            df['price'] = df['price'].fillna(median_price)
        
        # Fill missing ratings with 0 or median
        if 'rating' in df.columns:
            df['rating'] = df['rating'].fillna(0.0)
        
        # Fill missing categorical data
        categorical_columns = ['colors', 'size', 'gender']
        for col in categorical_columns:
            if col in df.columns:
                df[col] = df[col].fillna('Unknown')
        
        # 7. Validate data types
        if 'price' in df.columns:
            df['price'] = pd.to_numeric(df['price'], errors='coerce')
        
        if 'rating' in df.columns:
            df['rating'] = pd.to_numeric(df['rating'], errors='coerce')
            # Ensure rating is between 0-5
            df['rating'] = df['rating'].clip(lower=0, upper=5)
        
        # 8. Remove any rows that still have null in critical columns
        critical_columns = ['title', 'price']
        for col in critical_columns:
            if col in df.columns:
                df = df.dropna(subset=[col])
        
        # 9. Remove rows with zero or negative prices
        if 'price' in df.columns:
            df = df[df['price'] > 0]
        
        final_shape = df.shape
        logger.info(f"Data cleaning completed: {initial_shape} -> {final_shape}")
        logger.info(f"Removed {initial_shape[0] - final_shape[0]} rows")
        
        return df
        
    except Exception as e:
        logger.error(f"Error in comprehensive data cleaning: {e}")
        return df
    """
    Validate and convert data types with error handling

    Args:
        df: DataFrame to validate
        type_mapping: Dictionary mapping column names to desired data types

    Returns:
        DataFrame with validated data types
    """
    try:
        logger.info("Validating and converting data types")
        df_copy = df.copy()

        for column, target_type in type_mapping.items():
            if column not in df_copy.columns:
                logger.warning(f"Column '{column}' not found for type conversion")
                continue

            try:
                current_type = str(df_copy[column].dtype)
                logger.info(f"Converting '{column}' from {current_type} to {target_type}")

                if target_type == 'int64':
                    df_copy[column] = pd.to_numeric(df_copy[column], errors='coerce').astype('Int64')
                elif target_type == 'float64':
                    df_copy[column] = pd.to_numeric(df_copy[column], errors='coerce')
                elif target_type == 'datetime64[ns]':
                    df_copy[column] = pd.to_datetime(df_copy[column], errors='coerce')
                elif target_type == 'category':
                    df_copy[column] = df_copy[column].astype('category')
                elif target_type == 'string':
                    df_copy[column] = df_copy[column].astype('string')
                else:
                    df_copy[column] = df_copy[column].astype(target_type)

            except Exception as col_error:
                logger.error(f"Error converting column '{column}' to {target_type}: {col_error}")
                continue

        logger.info("Data type validation completed")
        return df_copy

    except Exception as e:
        logger.error(f"Error during data type validation: {e}")
        return df

def transform_data_pipeline(df: pd.DataFrame, config: Dict[str, Any]) -> pd.DataFrame:
    """
    Main transformation pipeline that applies multiple transformations

    Args:
        df: Input DataFrame
        config: Configuration dictionary specifying transformations to apply

    Returns:
        Transformed DataFrame
    """
    try:
        logger.info("Starting data transformation pipeline")

        if df.empty:
            logger.warning("Input DataFrame is empty")
            return df

        logger.info(f"Initial data shape: {df.shape}")
        logger.info(f"Initial columns: {list(df.columns)}")

        transformed_df = df.copy()
        
        # Check if this is fashion data and apply comprehensive cleaning
        required_fashion_columns = ['title', 'price', 'rating', 'colors', 'size', 'gender']
        is_fashion_data = all(col in df.columns for col in required_fashion_columns)
        
        if is_fashion_data:
            logger.info("Detected fashion data - applying comprehensive cleaning")
            transformed_df = clean_fashion_data(transformed_df)
        else:
            # Apply standard transformations
            if config.get('handle_missing', False):
                missing_strategy = config.get('missing_strategy', 'median')
                custom_values = config.get('custom_missing_values')
                transformed_df = handle_missing_values(transformed_df, missing_strategy, custom_values)

            if config.get('remove_duplicates', False):
                subset = config.get('duplicate_subset')
                keep = config.get('duplicate_keep', 'first')
                transformed_df = remove_duplicates(transformed_df, subset, keep)

            if config.get('clean_text', False):
                text_columns = config.get('text_columns', [])
                for col in text_columns:
                    if col in transformed_df.columns:
                        transformed_df[col] = clean_text_data(transformed_df[col])

            if config.get('standardize_dates', False):
                date_columns = config.get('date_columns', [])
                date_format = config.get('date_format', '%Y-%m-%d')
                transformed_df = standardize_date_format(transformed_df, date_columns, date_format)

            if config.get('validate_types', False):
                type_mapping = config.get('type_mapping', {})
                transformed_df = validate_data_types(transformed_df, type_mapping)

            if config.get('normalize_numeric', False):
                numeric_columns = config.get('numeric_columns', [])
                transformed_df = normalize_numeric_data(transformed_df, numeric_columns)

        logger.info(f"Final data shape: {transformed_df.shape}")
        logger.info("Data transformation pipeline completed successfully")

        return transformed_df

    except Exception as e:
        logger.error(f"Error in transformation pipeline: {e}")
        return df
