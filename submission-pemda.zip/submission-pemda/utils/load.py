"""
Load module for ETL pipeline
This module handles data loading to various destinations with proper error handling
"""

import pandas as pd
import json
import sqlite3
import logging
import os
from typing import Dict, List, Any, Optional
from sqlalchemy import create_engine, text
import csv

try:
    import gspread
    from google.oauth2.service_account import Credentials
    GOOGLE_SHEETS_AVAILABLE = True
except ImportError:
    GOOGLE_SHEETS_AVAILABLE = False

try:
    import psycopg2
    from psycopg2.extras import RealDictCursor
    POSTGRESQL_AVAILABLE = True
except ImportError:
    POSTGRESQL_AVAILABLE = False

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def save_to_csv(df: pd.DataFrame, file_path: str, encoding: str = 'utf-8',
                index: bool = False, mode: str = 'w') -> bool:
    """
    Save DataFrame to CSV file with error handling

    Args:
        df: DataFrame to save
        file_path: Path where to save the CSV file
        encoding: File encoding
        index: Whether to include row indices
        mode: Write mode ('w' for write, 'a' for append)

    Returns:
        bool: True if successful, False otherwise
    """
    try:
        logger.info(f"Saving data to CSV: {file_path}")

        os.makedirs(os.path.dirname(file_path), exist_ok=True)

        if df.empty:
            logger.warning("DataFrame is empty, saving empty CSV")

        df.to_csv(file_path, encoding=encoding, index=index, mode=mode)

        if os.path.exists(file_path):
            file_size = os.path.getsize(file_path)
            logger.info(f"Successfully saved {len(df)} rows to CSV. File size: {file_size} bytes")
            return True
        else:
            logger.error("CSV file was not created")
            return False

    except PermissionError:
        logger.error(f"Permission denied when writing to: {file_path}")
        return False
    except pd.errors.EmptyDataError:
        logger.error("Cannot save empty DataFrame")
        return False
    except UnicodeEncodeError as e:
        logger.error(f"Encoding error when saving CSV: {e}")
        try:
            logger.info("Attempting to save with latin-1 encoding")
            df.to_csv(file_path, encoding='latin-1', index=index, mode=mode)
            return True
        except Exception as fallback_error:
            logger.error(f"Fallback encoding also failed: {fallback_error}")
            return False
    except Exception as e:
        logger.error(f"Unexpected error saving CSV: {e}")
        return False

def save_to_json(data: Any, file_path: str, encoding: str = 'utf-8',
                 indent: int = 2, ensure_ascii: bool = False) -> bool:
    """
    Save data to JSON file with error handling

    Args:
        data: Data to save (dict, list, or DataFrame)
        file_path: Path where to save the JSON file
        encoding: File encoding
        indent: JSON indentation
        ensure_ascii: Whether to escape non-ASCII characters

    Returns:
        bool: True if successful, False otherwise
    """
    try:
        logger.info(f"Saving data to JSON: {file_path}")

        os.makedirs(os.path.dirname(file_path), exist_ok=True)

        if isinstance(data, pd.DataFrame):
            if data.empty:
                logger.warning("DataFrame is empty")
                data = {}
            else:
                data = data.to_dict(orient='records')

        with open(file_path, 'w', encoding=encoding) as file:
            json.dump(data, file, indent=indent, ensure_ascii=ensure_ascii, default=str)

        if os.path.exists(file_path):
            file_size = os.path.getsize(file_path)
            logger.info(f"Successfully saved data to JSON. File size: {file_size} bytes")
            return True
        else:
            logger.error("JSON file was not created")
            return False

    except PermissionError:
        logger.error(f"Permission denied when writing to: {file_path}")
        return False
    except TypeError as e:
        logger.error(f"Data serialization error: {e}")
        try:
            logger.info("Attempting to save with string conversion")
            with open(file_path, 'w', encoding=encoding) as file:
                json.dump(data, file, indent=indent, ensure_ascii=ensure_ascii, default=str)
            return True
        except Exception as fallback_error:
            logger.error(f"Fallback serialization also failed: {fallback_error}")
            return False
    except UnicodeEncodeError as e:
        logger.error(f"Encoding error when saving JSON: {e}")
        return False
    except Exception as e:
        logger.error(f"Unexpected error saving JSON: {e}")
        return False

def save_to_database(df: pd.DataFrame, connection_string: str, table_name: str,
                    if_exists: str = 'replace', index: bool = False) -> bool:
    """
    Save DataFrame to database with error handling

    Args:
        df: DataFrame to save
        connection_string: Database connection string
        table_name: Name of the target table
        if_exists: What to do if table exists ('fail', 'replace', 'append')
        index: Whether to include row indices

    Returns:
        bool: True if successful, False otherwise
    """
    try:
        logger.info(f"Saving data to database table: {table_name}")

        if df.empty:
            logger.warning("DataFrame is empty, creating empty table")

        engine = create_engine(connection_string)

        with engine.connect() as connection:
            connection.execute(text("SELECT 1"))
            logger.info("Database connection successful")

        rows_affected = df.to_sql(
            name=table_name,
            con=engine,
            if_exists=if_exists,
            index=index,
            method='multi'
        )

        logger.info(f"Successfully saved {len(df)} rows to database table '{table_name}'")
        return True

    except ImportError as e:
        logger.error(f"Database driver not available: {e}")
        return False
    except Exception as db_error:
        logger.error(f"Database operation failed: {db_error}")

        if "no such table" in str(db_error).lower():
            logger.error("Table does not exist and if_exists='fail'")
        elif "connection" in str(db_error).lower():
            logger.error("Database connection failed - check connection string")
        elif "permission" in str(db_error).lower():
            logger.error("Database permission denied")

        return False

def save_to_sqlite(df: pd.DataFrame, db_path: str, table_name: str,
                  if_exists: str = 'replace', index: bool = False) -> bool:
    """
    Save DataFrame to SQLite database with error handling

    Args:
        df: DataFrame to save
        db_path: Path to SQLite database file
        table_name: Name of the target table
        if_exists: What to do if table exists ('fail', 'replace', 'append')
        index: Whether to include row indices

    Returns:
        bool: True if successful, False otherwise
    """
    try:
        logger.info(f"Saving data to SQLite database: {db_path}")

        os.makedirs(os.path.dirname(db_path), exist_ok=True)

        if df.empty:
            logger.warning("DataFrame is empty")

        with sqlite3.connect(db_path) as conn:
            df.to_sql(
                name=table_name,
                con=conn,
                if_exists=if_exists,
                index=index
            )

            cursor = conn.cursor()
            cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
            row_count = cursor.fetchone()[0]

            logger.info(f"Successfully saved data to SQLite. Table '{table_name}' has {row_count} rows")
            return True

    except sqlite3.Error as e:
        logger.error(f"SQLite error: {e}")
        return False
    except pd.errors.DatabaseError as e:
        logger.error(f"Pandas database error: {e}")
        return False
    except Exception as e:
        logger.error(f"Error saving to SQLite: {e}")
        return False

def save_to_google_sheets(df: pd.DataFrame, spreadsheet_name: str,
                         worksheet_name: str = 'Sheet1',
                         credentials_path: str = 'service-account-key.json',
                         share_with_link: bool = True) -> bool:
    """
    Save DataFrame to Google Sheets with error handling

    Args:
        df: DataFrame to save
        spreadsheet_name: Name of the Google Spreadsheet
        worksheet_name: Name of the worksheet within the spreadsheet
        credentials_path: Path to service account credentials JSON file
        share_with_link: Whether to share the sheet with "Anyone with the link" as editor

    Returns:
        bool: True if successful, False otherwise
    """
    try:
        if not GOOGLE_SHEETS_AVAILABLE:
            logger.error("Google Sheets dependencies not installed. Install with: pip install gspread google-auth")
            return False

        logger.info(f"Saving data to Google Sheets: {spreadsheet_name}")

        if df.empty:
            logger.warning("DataFrame is empty")

        if not os.path.exists(credentials_path):
            logger.error(f"Service account credentials file not found: {credentials_path}")
            logger.info("Please ensure you have downloaded the service account key from Google Cloud Console")
            return False

        scopes = [
            'https://www.googleapis.com/auth/spreadsheets',
            'https://www.googleapis.com/auth/drive'
        ]

        credentials = Credentials.from_service_account_file(credentials_path, scopes=scopes)
        gc = gspread.authorize(credentials)

        try:
            spreadsheet = gc.open(spreadsheet_name)
            logger.info(f"Opened existing spreadsheet: {spreadsheet_name}")
        except gspread.SpreadsheetNotFound:
            logger.info(f"Creating new spreadsheet: {spreadsheet_name}")
            spreadsheet = gc.create(spreadsheet_name)

        try:
            worksheet = spreadsheet.worksheet(worksheet_name)
            worksheet.clear()
            logger.info(f"Cleared existing worksheet: {worksheet_name}")
        except gspread.WorksheetNotFound:
            logger.info(f"Creating new worksheet: {worksheet_name}")
            worksheet = spreadsheet.add_worksheet(title=worksheet_name, rows=1000, cols=50)

        data_to_upload = [df.columns.tolist()] + df.values.tolist()

        worksheet.update('A1', data_to_upload)

        if len(df) > 0:
            header_range = f'A1:{chr(65 + len(df.columns) - 1)}1'
            worksheet.format(header_range, {
                'backgroundColor': {'red': 0.8, 'green': 0.8, 'blue': 0.8},
                'textFormat': {'bold': True}
            })

        if share_with_link:
            try:
                spreadsheet.share('', perm_type='anyone', role='writer')
                logger.info("Spreadsheet shared with 'Anyone with the link' as EDITOR")
            except Exception as share_error:
                logger.warning(f"Could not set sharing permissions: {share_error}")

        spreadsheet_url = f"https://docs.google.com/spreadsheets/d/{spreadsheet.id}"
        logger.info(f"Successfully saved {len(df)} rows to Google Sheets")
        logger.info(f"Spreadsheet URL: {spreadsheet_url}")

        return True

    except FileNotFoundError:
        logger.error(f"Credentials file not found: {credentials_path}")
        return False
    except gspread.exceptions.APIError as e:
        logger.error(f"Google Sheets API error: {e}")
        logger.info("Please check your API quotas and credentials")
        return False
    except Exception as e:
        logger.error(f"Error saving to Google Sheets: {e}")
        return False

def save_to_postgresql(df: pd.DataFrame, connection_params: Dict[str, str],
                      table_name: str, if_exists: str = 'replace',
                      index: bool = False) -> bool:
    """
    Save DataFrame to PostgreSQL database with error handling

    Args:
        df: DataFrame to save
        connection_params: Dictionary with PostgreSQL connection parameters
                          (host, database, user, password, port)
        table_name: Name of the target table
        if_exists: What to do if table exists ('fail', 'replace', 'append')
        index: Whether to include row indices

    Returns:
        bool: True if successful, False otherwise
    """
    try:
        if not POSTGRESQL_AVAILABLE:
            logger.error("PostgreSQL dependencies not installed. Install with: pip install psycopg2-binary")
            return False

        logger.info(f"Saving data to PostgreSQL table: {table_name}")

        if df.empty:
            logger.warning("DataFrame is empty")

        required_params = ['host', 'database', 'user', 'password']
        missing_params = [param for param in required_params if param not in connection_params]
        if missing_params:
            logger.error(f"Missing connection parameters: {missing_params}")
            return False

        connection_params.setdefault('port', 5432)

        connection_string = (
            f"postgresql://{connection_params['user']}:{connection_params['password']}"
            f"@{connection_params['host']}:{connection_params['port']}/{connection_params['database']}"
        )

        engine = create_engine(connection_string)

        with engine.connect() as connection:
            connection.execute(text("SELECT 1"))
            logger.info("PostgreSQL connection successful")

        rows_affected = df.to_sql(
            name=table_name,
            con=engine,
            if_exists=if_exists,
            index=index,
            method='multi'
        )

        with engine.connect() as connection:
            result = connection.execute(text(f"SELECT COUNT(*) FROM {table_name}"))
            row_count = result.fetchone()[0]

        logger.info(f"Successfully saved {len(df)} rows to PostgreSQL table '{table_name}'")
        logger.info(f"Table now contains {row_count} total rows")

        return True

    except Exception as db_error:
        logger.error(f"PostgreSQL operation failed: {db_error}")

        error_msg = str(db_error).lower()
        if "connection" in error_msg:
            logger.error("Database connection failed - check host, port, and credentials")
        elif "authentication" in error_msg or "password" in error_msg:
            logger.error("Database authentication failed - check username and password")
        elif "database" in error_msg and "does not exist" in error_msg:
            logger.error("Target database does not exist")
        elif "permission" in error_msg:
            logger.error("Database permission denied - check user privileges")
        elif "relation" in error_msg and "does not exist" in error_msg:
            logger.error("Table does not exist and if_exists='fail'")

        return False

def append_to_existing_csv(df: pd.DataFrame, file_path: str, encoding: str = 'utf-8') -> bool:
    """
    Append DataFrame to existing CSV file with error handling

    Args:
        df: DataFrame to append
        file_path: Path to existing CSV file
        encoding: File encoding

    Returns:
        bool: True if successful, False otherwise
    """
    try:
        logger.info(f"Appending data to existing CSV: {file_path}")

        if not os.path.exists(file_path):
            logger.warning(f"CSV file does not exist, creating new file: {file_path}")
            return save_to_csv(df, file_path, encoding)

        df.to_csv(file_path, mode='a', header=False, index=False, encoding=encoding)

        logger.info(f"Successfully appended {len(df)} rows to CSV")
        return True

    except Exception as e:
        logger.error(f"Error appending to CSV: {e}")
        return False

def validate_load_operation(file_path: str, expected_rows: Optional[int] = None) -> bool:
    """
    Validate that load operation was successful

    Args:
        file_path: Path to the saved file
        expected_rows: Expected number of rows (for CSV validation)

    Returns:
        bool: True if validation passes, False otherwise
    """
    try:
        logger.info(f"Validating load operation for: {file_path}")

        if not os.path.exists(file_path):
            logger.error("Output file does not exist")
            return False

        file_size = os.path.getsize(file_path)
        if file_size == 0:
            logger.error("Output file is empty")
            return False

        if file_path.endswith('.csv') and expected_rows is not None:
            try:
                df = pd.read_csv(file_path)
                actual_rows = len(df)
                if actual_rows != expected_rows:
                    logger.warning(f"Row count mismatch: expected {expected_rows}, got {actual_rows}")
                else:
                    logger.info(f"Row count validation passed: {actual_rows} rows")
            except Exception as csv_error:
                logger.error(f"Error validating CSV content: {csv_error}")
                return False

        logger.info("Load operation validation passed")
        return True

    except Exception as e:
        logger.error(f"Error during validation: {e}")
        return False

def load_data_pipeline(df: pd.DataFrame, config: Dict[str, Any]) -> Dict[str, bool]:
    """
    Main loading pipeline that can save to multiple destinations

    Args:
        df: DataFrame to save
        config: Configuration dictionary specifying load operations

    Returns:
        Dict with operation names and their success status
    """
    try:
        logger.info("Starting data loading pipeline")
        results = {}

        if df.empty:
            logger.warning("Input DataFrame is empty")
            return {"warning": "empty_dataframe"}

        if config.get('save_csv', False):
            csv_path = config.get('csv_path', 'output/data.csv')
            csv_encoding = config.get('csv_encoding', 'utf-8')
            results['csv'] = save_to_csv(df, csv_path, csv_encoding)

        if config.get('save_json', False):
            json_path = config.get('json_path', 'output/data.json')
            json_encoding = config.get('json_encoding', 'utf-8')
            results['json'] = save_to_json(df, json_path, json_encoding)

        if config.get('save_sqlite', False):
            sqlite_path = config.get('sqlite_path', 'output/data.db')
            table_name = config.get('table_name', 'data_table')
            if_exists = config.get('if_exists', 'replace')
            results['sqlite'] = save_to_sqlite(df, sqlite_path, table_name, if_exists)

        if config.get('save_database', False):
            connection_string = config.get('connection_string')
            table_name = config.get('db_table_name', 'data_table')
            if_exists = config.get('db_if_exists', 'replace')
            if connection_string:
                results['database'] = save_to_database(df, connection_string, table_name, if_exists)
            else:
                logger.error("Database connection string not provided")
                results['database'] = False

        if config.get('save_google_sheets', False):
            spreadsheet_name = config.get('spreadsheet_name', 'ETL Pipeline Data')
            worksheet_name = config.get('worksheet_name', 'Sheet1')
            credentials_path = config.get('google_credentials_path', 'service-account-key.json')
            share_with_link = config.get('share_with_link', True)
            results['google_sheets'] = save_to_google_sheets(
                df, spreadsheet_name, worksheet_name, credentials_path, share_with_link
            )

        if config.get('save_postgresql', False):
            connection_params = config.get('postgresql_params', {})
            table_name = config.get('postgresql_table_name', 'data_table')
            if_exists = config.get('postgresql_if_exists', 'replace')
            if connection_params:
                results['postgresql'] = save_to_postgresql(df, connection_params, table_name, if_exists)
            else:
                logger.error("PostgreSQL connection parameters not provided")
                results['postgresql'] = False

        successful_operations = sum(1 for success in results.values() if success is True)
        total_operations = len(results)
        logger.info(f"Loading pipeline completed: {successful_operations}/{total_operations} operations successful")

        return results

    except Exception as e:
        logger.error(f"Error in loading pipeline: {e}")
        return {"error": str(e)}
