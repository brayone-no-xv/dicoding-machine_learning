"""
Main ETL Pipeline Orchestrator
This module orchestrates the complete ETL pipeline with error handling and logging
"""

import pandas as pd
import logging
import json
import sys
import os
from datetime import datetime
from typing import Dict, Any, Optional

sys.path.append(os.path.join(os.path.dirname(__file__), 'utils'))

from utils.extract import scrape_main, extract_from_csv, extract_from_api, validate_extracted_data
from utils.transform import transform_data_pipeline
from utils.load import load_data_pipeline

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('etl_pipeline.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def load_config(config_path: str = 'config.json') -> Dict[str, Any]:
    """
    Load configuration file with error handling

    Args:
        config_path: Path to configuration JSON file

    Returns:
        Configuration dictionary or default config on error
    """
    try:
        logger.info(f"Loading configuration from: {config_path}")

        if not os.path.exists(config_path):
            logger.warning(f"Config file not found: {config_path}. Using default configuration.")
            return get_default_config()

        with open(config_path, 'r', encoding='utf-8') as file:
            config = json.load(file)

        logger.info("Configuration loaded successfully")
        return config

    except json.JSONDecodeError as e:
        logger.error(f"Invalid JSON in config file: {e}")
        return get_default_config()
    except Exception as e:
        logger.error(f"Error loading config: {e}")
        return get_default_config()

def get_default_config() -> Dict[str, Any]:
    """
    Get default configuration for ETL pipeline

    Returns:
        Default configuration dictionary
    """
    return {
        "extract": {
            "source_type": "csv",
            "source_path": "products.csv",
            "api_url": "",
            "timeout": 30
        },
        "transform": {
            "handle_missing": True,
            "missing_strategy": "median",
            "remove_duplicates": True,
            "clean_text": True,
            "text_columns": [],
            "standardize_dates": False,
            "date_columns": [],
            "validate_types": True,
            "type_mapping": {},
            "normalize_numeric": False,
            "numeric_columns": []
        },
        "load": {
            "save_csv": True,
            "csv_path": "output/processed_data.csv",
            "save_json": True,
            "json_path": "output/processed_data.json",
            "save_sqlite": False,
            "sqlite_path": "output/data.db",
            "table_name": "processed_data"
        }
    }

def run_extract_phase(config: Dict[str, Any]) -> Optional[pd.DataFrame]:
    """
    Execute the extract phase of ETL pipeline

    Args:
        config: Extract configuration

    Returns:
        Extracted DataFrame or None on failure
    """
    try:
        logger.info("=" * 50)
        logger.info("STARTING EXTRACT PHASE")
        logger.info("=" * 50)

        source_type = config.get('source_type', 'csv')

        if source_type == 'csv':
            source_path = config.get('source_path', 'products.csv')
            logger.info(f"Extracting data from CSV: {source_path}")
            df = extract_from_csv(source_path)

        elif source_type == 'api':
            api_url = config.get('api_url')
            timeout = config.get('timeout', 30)
            if not api_url:
                logger.error("API URL not provided in configuration")
                return None

            logger.info(f"Extracting data from API: {api_url}")
            api_data = extract_from_api(api_url, timeout=timeout)

            if 'error' in api_data:
                logger.error(f"API extraction failed: {api_data['error']}")
                return None

            if isinstance(api_data, list):
                df = pd.DataFrame(api_data)
            elif isinstance(api_data, dict):
                if 'data' in api_data:
                    df = pd.DataFrame(api_data['data'])
                elif 'results' in api_data:
                    df = pd.DataFrame(api_data['results'])
                else:
                    df = pd.DataFrame([api_data])
            else:
                df = pd.DataFrame()

        elif source_type == 'web_scraping':
            url = config.get('url')
            timeout = config.get('timeout', 30)
            if not url:
                logger.error("URL not provided for web scraping")
                return None

            logger.info(f"Scraping data from: {url}")
            scraped_data = scrape_main(url, timeout=timeout)
            df = pd.DataFrame(scraped_data)

        else:
            logger.error(f"Unsupported source type: {source_type}")
            return None

        if df.empty:
            logger.warning("No data extracted")
            return None

        logger.info(f"Extract phase completed successfully. Extracted {len(df)} rows, {len(df.columns)} columns")
        logger.info(f"Columns: {list(df.columns)}")

        return df

    except Exception as e:
        logger.error(f"Extract phase failed: {e}")
        return None

def run_transform_phase(df: pd.DataFrame, config: Dict[str, Any]) -> Optional[pd.DataFrame]:
    """
    Execute the transform phase of ETL pipeline

    Args:
        df: DataFrame to transform
        config: Transform configuration

    Returns:
        Transformed DataFrame or None on failure
    """
    try:
        logger.info("=" * 50)
        logger.info("STARTING TRANSFORM PHASE")
        logger.info("=" * 50)

        if df is None or df.empty:
            logger.error("No data provided for transformation")
            return None

        logger.info(f"Input data shape: {df.shape}")

        transformed_df = transform_data_pipeline(df, config)

        if transformed_df is None or transformed_df.empty:
            logger.error("Transformation resulted in empty dataset")
            return None

        logger.info(f"Transform phase completed successfully. Output shape: {transformed_df.shape}")

        rows_changed = len(df) - len(transformed_df)
        if rows_changed != 0:
            logger.info(f"Row count changed by: {rows_changed}")

        return transformed_df

    except Exception as e:
        logger.error(f"Transform phase failed: {e}")
        return None

def run_load_phase(df: pd.DataFrame, config: Dict[str, Any]) -> Dict[str, bool]:
    """
    Execute the load phase of ETL pipeline

    Args:
        df: DataFrame to load
        config: Load configuration

    Returns:
        Dictionary with load operation results
    """
    try:
        logger.info("=" * 50)
        logger.info("STARTING LOAD PHASE")
        logger.info("=" * 50)

        if df is None or df.empty:
            logger.error("No data provided for loading")
            return {"error": "no_data"}

        logger.info(f"Loading {len(df)} rows to specified destinations")

        output_paths = [config.get('csv_path', ''), config.get('json_path', ''), config.get('sqlite_path', '')]
        for path in output_paths:
            if path:
                os.makedirs(os.path.dirname(path), exist_ok=True)

        load_results = load_data_pipeline(df, config)

        logger.info("Load phase completed")

        for operation, success in load_results.items():
            if success:
                logger.info(f"✓ {operation.upper()} load successful")
            else:
                logger.error(f"✗ {operation.upper()} load failed")

        return load_results

    except Exception as e:
        logger.error(f"Load phase failed: {e}")
        return {"error": str(e)}

def run_etl_pipeline(config_path: str = 'config.json') -> bool:
    """
    Main function to run the complete ETL pipeline

    Args:
        config_path: Path to configuration file

    Returns:
        True if pipeline completed successfully, False otherwise
    """
    try:
        start_time = datetime.now()
        logger.info("*" * 60)
        logger.info("STARTING ETL PIPELINE")
        logger.info(f"Start time: {start_time}")
        logger.info("*" * 60)

        config = load_config(config_path)

        extracted_df = run_extract_phase(config.get('extract', {}))
        if extracted_df is None:
            logger.error("ETL Pipeline failed at extract phase")
            return False

        transformed_df = run_transform_phase(extracted_df, config.get('transform', {}))
        if transformed_df is None:
            logger.error("ETL Pipeline failed at transform phase")
            return False

        load_results = run_load_phase(transformed_df, config.get('load', {}))

        successful_loads = sum(1 for result in load_results.values() if result is True)
        if successful_loads == 0:
            logger.error("ETL Pipeline failed: no successful load operations")
            return False

        end_time = datetime.now()
        duration = end_time - start_time

        logger.info("*" * 60)
        logger.info("ETL PIPELINE COMPLETED SUCCESSFULLY")
        logger.info(f"End time: {end_time}")
        logger.info(f"Duration: {duration}")
        logger.info(f"Processed {len(transformed_df)} rows")
        logger.info(f"Successful load operations: {successful_loads}/{len(load_results)}")
        logger.info("*" * 60)

        return True

    except Exception as e:
        logger.error(f"ETL Pipeline failed with unexpected error: {e}")
        return False

def create_sample_config():
    """
    Create a sample configuration file for reference
    """
    sample_config = {
        "extract": {
            "source_type": "csv",
            "source_path": "products.csv",
            "api_url": "https://api.example.com/products",
            "timeout": 30
        },
        "transform": {
            "handle_missing": True,
            "missing_strategy": "median",
            "remove_duplicates": True,
            "clean_text": True,
            "text_columns": ["name", "description"],
            "standardize_dates": True,
            "date_columns": ["created_date", "updated_date"],
            "validate_types": True,
            "type_mapping": {
                "price": "float64",
                "quantity": "int64",
                "created_date": "datetime64[ns]"
            },
            "normalize_numeric": False,
            "numeric_columns": ["price", "quantity"]
        },
        "load": {
            "save_csv": True,
            "csv_path": "output/processed_data.csv",
            "save_json": True,
            "json_path": "output/processed_data.json",
            "save_sqlite": True,
            "sqlite_path": "output/data.db",
            "table_name": "processed_data"
        }
    }

    try:
        with open('config_sample.json', 'w', encoding='utf-8') as file:
            json.dump(sample_config, file, indent=2)
        logger.info("Sample configuration file created: config_sample.json")
    except Exception as e:
        logger.error(f"Error creating sample config: {e}")

if __name__ == "__main__":
    try:
        if not os.path.exists('config.json') and not os.path.exists('config_sample.json'):
            create_sample_config()

        success = run_etl_pipeline()

        if success:
            print("ETL Pipeline completed successfully!")
            sys.exit(0)
        else:
            print("ETL Pipeline failed. Check logs for details.")
            sys.exit(1)

    except KeyboardInterrupt:
        logger.info("ETL Pipeline interrupted by user")
        sys.exit(1)
    except Exception as e:
        logger.error(f"Critical error in main execution: {e}")
        sys.exit(1)
