# PostgreSQL Setup Guide for ETL Pipeline

## Prerequisites
- PostgreSQL installed and running
- Database user with appropriate privileges
- Network access to PostgreSQL server

## Local PostgreSQL Setup (Development)

### Step 1: Install PostgreSQL
#### On Ubuntu/Debian:
```bash
sudo apt update
sudo apt install postgresql postgresql-contrib
```

#### On macOS (using Homebrew):
```bash
brew install postgresql
brew services start postgresql
```

#### On Windows:
Download and install from [PostgreSQL official website](https://www.postgresql.org/download/windows/)

### Step 2: Create Database and User
```bash
# Connect to PostgreSQL as superuser
sudo -u postgres psql

# Create database
CREATE DATABASE etl_database;

# Create user
CREATE USER etl_user WITH PASSWORD 'secure_password_here';

# Grant privileges
GRANT ALL PRIVILEGES ON DATABASE etl_database TO etl_user;

# Grant usage on schema
\c etl_database
GRANT USAGE ON SCHEMA public TO etl_user;
GRANT CREATE ON SCHEMA public TO etl_user;

# Exit
\q
```

### Step 3: Configure Connection
Update your `config.json`:
```json
{
  "load": {
    "save_postgresql": true,
    "postgresql_params": {
      "host": "localhost",
      "database": "etl_database",
      "user": "etl_user",
      "password": "secure_password_here",
      "port": 5432
    },
    "postgresql_table_name": "products",
    "postgresql_if_exists": "replace"
  }
}
```

## Cloud PostgreSQL Setup

### AWS RDS PostgreSQL
1. Create RDS PostgreSQL instance
2. Configure security groups for access
3. Update connection parameters:
```json
{
  "postgresql_params": {
    "host": "your-rds-endpoint.amazonaws.com",
    "database": "etl_database",
    "user": "postgres",
    "password": "your_password",
    "port": 5432
  }
}
```

### Google Cloud SQL for PostgreSQL
1. Create Cloud SQL PostgreSQL instance
2. Enable private/public IP as needed
3. Update connection parameters:
```json
{
  "postgresql_params": {
    "host": "your-cloud-sql-ip",
    "database": "etl_database",
    "user": "postgres",
    "password": "your_password",
    "port": 5432
  }
}
```

### Azure Database for PostgreSQL
1. Create Azure Database for PostgreSQL
2. Configure firewall rules
3. Update connection parameters:
```json
{
  "postgresql_params": {
    "host": "your-server.postgres.database.azure.com",
    "database": "etl_database",
    "user": "username@your-server",
    "password": "your_password",
    "port": 5432
  }
}
```

## Environment Variables (Production)
For production environments, use environment variables:

### Step 1: Create .env file
```bash
POSTGRESQL_HOST=localhost
POSTGRESQL_DATABASE=etl_database
POSTGRESQL_USER=etl_user
POSTGRESQL_PASSWORD=secure_password_here
POSTGRESQL_PORT=5432
```

### Step 2: Update your ETL pipeline to use environment variables
```python
import os
from dotenv import load_dotenv

load_dotenv()

postgresql_params = {
    "host": os.getenv("POSTGRESQL_HOST"),
    "database": os.getenv("POSTGRESQL_DATABASE"),
    "user": os.getenv("POSTGRESQL_USER"),
    "password": os.getenv("POSTGRESQL_PASSWORD"),
    "port": int(os.getenv("POSTGRESQL_PORT", 5432))
}
```

## Testing the Connection

### Test Connection Script
Create a test file `test_postgresql.py`:
```python
import psycopg2
from psycopg2.extras import RealDictCursor

connection_params = {
    "host": "localhost",
    "database": "etl_database",
    "user": "etl_user",
    "password": "secure_password_here",
    "port": 5432
}

try:
    conn = psycopg2.connect(**connection_params)
    cursor = conn.cursor(cursor_factory=RealDictCursor)
    cursor.execute("SELECT version();")
    result = cursor.fetchone()
    print(f"PostgreSQL version: {result['version']}")
    print("Connection successful!")
    
except psycopg2.Error as e:
    print(f"Database connection failed: {e}")
    
finally:
    if conn:
        conn.close()
```

Run the test:
```bash
python test_postgresql.py
```

## Security Best Practices

1. **Use strong passwords**: Generate secure passwords for database users
2. **Limit user privileges**: Grant only necessary permissions
3. **Network security**: Use VPN or private networks for cloud connections
4. **SSL/TLS**: Enable SSL for encrypted connections
5. **Environment variables**: Never hardcode credentials in code
6. **Regular backups**: Implement backup strategies for data protection

## Troubleshooting

### Common Issues:

1. **Connection refused**:
   - Check if PostgreSQL is running: `sudo systemctl status postgresql`
   - Verify port availability: `netstat -tlnp | grep 5432`

2. **Authentication failed**:
   - Check username and password
   - Verify user exists: `SELECT * FROM pg_user WHERE usename = 'etl_user';`

3. **Database does not exist**:
   - Create database: `CREATE DATABASE etl_database;`
   - Verify database exists: `\l` in psql

4. **Permission denied**:
   - Grant necessary privileges to user
   - Check schema permissions

5. **Connection timeout**:
   - Check network connectivity
   - Verify firewall rules
   - Check PostgreSQL configuration (pg_hba.conf, postgresql.conf)

## Performance Optimization

1. **Connection pooling**: Use pgbouncer or similar for high-load scenarios
2. **Batch inserts**: Use pandas `method='multi'` parameter
3. **Indexes**: Create appropriate indexes on frequently queried columns
4. **Table partitioning**: For large datasets, consider partitioning
5. **Memory settings**: Tune PostgreSQL memory parameters

## Monitoring
- Check connection counts: `SELECT count(*) FROM pg_stat_activity;`
- Monitor table sizes: `SELECT pg_size_pretty(pg_total_relation_size('table_name'));`
- Check query performance: Use `EXPLAIN ANALYZE` for query optimization