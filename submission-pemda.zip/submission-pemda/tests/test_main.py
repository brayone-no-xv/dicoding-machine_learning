"""
Unit tests for the main ETL pipeline orchestrator
"""

import unittest
import pandas as pd
import json
import os
import tempfile
import sys
from unittest.mock import patch, mock_open, Mock, MagicMock
import shutil

sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from main import (
    load_config,
    get_default_config,
    run_extract_phase,
    run_transform_phase,
    run_load_phase,
    run_etl_pipeline,
    create_sample_config
)

class TestMainModule(unittest.TestCase):

    def setUp(self):
        """Set up test fixtures"""
        self.temp_dir = tempfile.mkdtemp()
        self.sample_config = {
            "extract": {
                "source_type": "csv",
                "source_path": "test.csv",
                "timeout": 30
            },
            "transform": {
                "handle_missing": True,
                "missing_strategy": "median"
            },
            "load": {
                "save_csv": True,
                "csv_path": os.path.join(self.temp_dir, "output.csv")
            }
        }

        self.sample_df = pd.DataFrame({
            'name': ['Product A', 'Product B'],
            'price': [10.5, 20.0],
            'quantity': [100, 50]
        })

    def tearDown(self):
        """Clean up test fixtures"""
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_get_default_config(self):
        """Test default configuration generation"""
        config = get_default_config()

        self.assertIn('extract', config)
        self.assertIn('transform', config)
        self.assertIn('load', config)

        self.assertEqual(config['extract']['source_type'], 'csv')
        self.assertEqual(config['transform']['handle_missing'], True)
        self.assertTrue(config['load']['save_csv'])

    def test_load_config_success(self):
        """Test successful config loading"""
        config_path = os.path.join(self.temp_dir, 'test_config.json')

        with open(config_path, 'w') as f:
            json.dump(self.sample_config, f)

        result = load_config(config_path)
        self.assertEqual(result, self.sample_config)

    def test_load_config_file_not_found(self):
        """Test config loading when file doesn't exist"""
        result = load_config('nonexistent_config.json')

        default_config = get_default_config()
        self.assertEqual(result, default_config)

    def test_load_config_invalid_json(self):
        """Test config loading with invalid JSON"""
        config_path = os.path.join(self.temp_dir, 'invalid_config.json')

        with open(config_path, 'w') as f:
            f.write("invalid json content")

        result = load_config(config_path)

        default_config = get_default_config()
        self.assertEqual(result, default_config)

    @patch('main.extract_from_csv')
    def test_run_extract_phase_csv_success(self, mock_extract):
        """Test successful CSV extraction phase"""
        mock_extract.return_value = self.sample_df

        config = {"source_type": "csv", "source_path": "test.csv"}
        result = run_extract_phase(config)

        self.assertIsNotNone(result)
        mock_extract.assert_called_once_with("test.csv")

    def test_run_extract_phase_unsupported_source(self):
        """Test extraction phase with unsupported source type"""
        config = {"source_type": "unsupported"}
        result = run_extract_phase(config)

        self.assertIsNone(result)

    @patch('main.transform_data_pipeline')
    def test_run_transform_phase_success(self, mock_transform):
        """Test successful transform phase"""
        mock_transform.return_value = self.sample_df

        config = {"handle_missing": True}
        result = run_transform_phase(self.sample_df, config)

        self.assertIsNotNone(result)
        mock_transform.assert_called_once_with(self.sample_df, config)

    def test_run_transform_phase_empty_input(self):
        """Test transform phase with empty input"""
        result = run_transform_phase(None, {})

        self.assertIsNone(result)

    @patch('main.load_data_pipeline')
    def test_run_load_phase_success(self, mock_load):
        """Test successful load phase"""
        mock_load.return_value = {'csv': True, 'json': True}

        config = {"save_csv": True, "save_json": True}
        result = run_load_phase(self.sample_df, config)

        self.assertIn('csv', result)
        self.assertTrue(result['csv'])
        mock_load.assert_called_once_with(self.sample_df, config)

    def test_run_load_phase_empty_input(self):
        """Test load phase with empty input"""
        result = run_load_phase(None, {})

        self.assertIn('error', result)
        self.assertEqual(result['error'], 'no_data')

    def test_create_sample_config(self):
        """Test sample config creation"""
        original_dir = os.getcwd()
        os.chdir(self.temp_dir)

        try:
            create_sample_config()

            self.assertTrue(os.path.exists('config_sample.json'))

            with open('config_sample.json', 'r') as f:
                config = json.load(f)

            self.assertIn('extract', config)
            self.assertIn('transform', config)
            self.assertIn('load', config)

        finally:
            os.chdir(original_dir)

    @patch('main.run_load_phase')
    @patch('main.run_transform_phase')
    @patch('main.run_extract_phase')
    @patch('main.load_config')
    def test_run_etl_pipeline_success(self, mock_load_config, mock_extract, mock_transform, mock_load):
        """Test successful complete ETL pipeline"""
        mock_load_config.return_value = self.sample_config
        mock_extract.return_value = self.sample_df
        mock_transform.return_value = self.sample_df
        mock_load.return_value = {'csv': True, 'json': True}

        original_dir = os.getcwd()
        os.chdir(self.temp_dir)

        try:
            result = run_etl_pipeline('test_config.json')
            self.assertTrue(result)

        finally:
            os.chdir(original_dir)

    @patch('main.run_extract_phase')
    @patch('main.load_config')
    def test_run_etl_pipeline_extract_failure(self, mock_load_config, mock_extract):
        """Test ETL pipeline failure at extract phase"""
        mock_load_config.return_value = self.sample_config
        mock_extract.return_value = None

        result = run_etl_pipeline('test_config.json')
        self.assertFalse(result)

    @patch('main.run_transform_phase')
    @patch('main.run_extract_phase')
    @patch('main.load_config')
    def test_run_etl_pipeline_transform_failure(self, mock_load_config, mock_extract, mock_transform):
        """Test ETL pipeline failure at transform phase"""
        mock_load_config.return_value = self.sample_config
        mock_extract.return_value = self.sample_df
        mock_transform.return_value = None

        result = run_etl_pipeline('test_config.json')
        self.assertFalse(result)

if __name__ == '__main__':
    unittest.main()
