"""
Unit tests for the extract module
"""

import unittest
import pandas as pd
import json
import os
import tempfile
import sys
from unittest.mock import patch, mock_open, Mock
import requests

sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'utils'))

from utils.extract import (
    scrape_main,
    extract_from_csv,
    extract_from_json,
    extract_from_api,
    validate_extracted_data
)

class TestExtractModule(unittest.TestCase):

    def setUp(self):
        """Set up test fixtures"""
        self.sample_csv_data = "name,price,quantity\nProduct A,10.5,100\nProduct B,20.0,50"
        self.sample_json_data = {"products": [{"name": "Product A", "price": 10.5}]}
        self.sample_api_response = [{"id": 1, "name": "Test Product"}]

    def test_extract_from_csv_success(self):
        """Test successful CSV extraction"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(self.sample_csv_data)
            temp_path = f.name

        try:
            result = extract_from_csv(temp_path)
            self.assertIsInstance(result, pd.DataFrame)
            self.assertEqual(len(result), 2)
            self.assertIn('name', result.columns)
            self.assertIn('price', result.columns)
        finally:
            os.unlink(temp_path)

    def test_extract_from_csv_file_not_found(self):
        """Test CSV extraction with non-existent file"""
        result = extract_from_csv('non_existent_file.csv')
        self.assertIsInstance(result, pd.DataFrame)
        self.assertTrue(result.empty)

    def test_extract_from_json_success(self):
        """Test successful JSON extraction"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(self.sample_json_data, f)
            temp_path = f.name

        try:
            result = extract_from_json(temp_path)
            self.assertIsInstance(result, dict)
            self.assertIn('products', result)
        finally:
            os.unlink(temp_path)

    def test_extract_from_json_file_not_found(self):
        """Test JSON extraction with non-existent file"""
        result = extract_from_json('non_existent_file.json')
        self.assertIsInstance(result, dict)
        self.assertEqual(result, {})

    def test_extract_from_json_invalid_json(self):
        """Test JSON extraction with invalid JSON"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            f.write("invalid json content")
            temp_path = f.name

        try:
            result = extract_from_json(temp_path)
            self.assertIsInstance(result, dict)
            self.assertEqual(result, {})
        finally:
            os.unlink(temp_path)

    @patch('utils.extract.requests.get')
    def test_scrape_main_success(self, mock_get):
        """Test successful web scraping"""
        mock_response = Mock()
        mock_response.json.return_value = {'products': self.sample_api_response}
        mock_response.raise_for_status.return_value = None
        mock_get.return_value = mock_response

        result = scrape_main('https://test-url.com')
        self.assertIsInstance(result, list)
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]['id'], 1)

    @patch('utils.extract.requests.get')
    def test_scrape_main_request_exception(self, mock_get):
        """Test web scraping with request exception"""
        mock_get.side_effect = requests.exceptions.RequestException("Connection error")

        result = scrape_main('https://test-url.com')
        self.assertIsInstance(result, list)
        self.assertEqual(len(result), 0)

    @patch('utils.extract.requests.get')
    def test_scrape_main_json_decode_error(self, mock_get):
        """Test web scraping with JSON decode error"""
        mock_response = Mock()
        mock_response.json.side_effect = json.JSONDecodeError("Invalid JSON", "", 0)
        mock_response.raise_for_status.return_value = None
        mock_response.text = "Invalid response"
        mock_get.return_value = mock_response

        result = scrape_main('https://test-url.com')
        self.assertIsInstance(result, list)
        self.assertEqual(len(result), 0)

    @patch('utils.extract.requests.get')
    def test_extract_from_api_success(self, mock_get):
        """Test successful API extraction"""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = self.sample_api_response
        mock_get.return_value = mock_response

        result = extract_from_api('https://api.test.com')
        self.assertIsInstance(result, list)
        self.assertEqual(len(result), 1)

    @patch('utils.extract.requests.get')
    def test_extract_from_api_404_error(self, mock_get):
        """Test API extraction with 404 error"""
        mock_response = Mock()
        mock_response.status_code = 404
        mock_get.return_value = mock_response

        result = extract_from_api('https://api.test.com')
        self.assertIsInstance(result, dict)
        self.assertEqual(result['status_code'], 404)
        self.assertEqual(result['error'], 'Endpoint not found')

    @patch('utils.extract.requests.get')
    def test_extract_from_api_timeout(self, mock_get):
        """Test API extraction with timeout"""
        mock_get.side_effect = requests.exceptions.Timeout()

        result = extract_from_api('https://api.test.com')
        self.assertIsInstance(result, dict)
        self.assertEqual(result['status_code'], 408)
        self.assertEqual(result['error'], 'Request timeout')

    def test_validate_extracted_data_valid_list(self):
        """Test data validation with valid list"""
        test_data = [{'id': 1}, {'id': 2}]
        result = validate_extracted_data(test_data, list)
        self.assertTrue(result)

    def test_validate_extracted_data_empty_list(self):
        """Test data validation with empty list"""
        test_data = []
        result = validate_extracted_data(test_data, list)
        self.assertFalse(result)

    def test_validate_extracted_data_wrong_type(self):
        """Test data validation with wrong data type"""
        test_data = "not a list"
        result = validate_extracted_data(test_data, list)
        self.assertFalse(result)

    def test_validate_extracted_data_valid_dict(self):
        """Test data validation with valid dictionary"""
        test_data = {'key': 'value'}
        result = validate_extracted_data(test_data, dict)
        self.assertTrue(result)

    def test_validate_extracted_data_empty_dict(self):
        """Test data validation with empty dictionary"""
        test_data = {}
        result = validate_extracted_data(test_data, dict)
        self.assertFalse(result)

    def test_extract_from_csv_unicode_error_recovery(self):
        """Test CSV extraction with encoding error and recovery"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write("name,price\nTest Product,10.50")
            temp_path = f.name

        try:
            result = extract_from_csv(temp_path)
            self.assertIsInstance(result, pd.DataFrame)
            self.assertGreater(len(result), 0)
            self.assertEqual(result.iloc[0]['name'], 'Test Product')
        finally:
            os.unlink(temp_path)

    @patch('utils.extract.requests.get')
    def test_extract_from_api_connection_error(self, mock_get):
        """Test API extraction with connection error"""
        mock_get.side_effect = requests.exceptions.ConnectionError("Network error")

        result = extract_from_api('https://api.test.com')
        self.assertIsInstance(result, dict)
        self.assertEqual(result['status_code'], 0)
        self.assertEqual(result['error'], 'Connection error')

    @patch('utils.extract.requests.get')
    def test_extract_from_api_with_headers_and_params(self, mock_get):
        """Test API extraction with custom headers and parameters"""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = self.sample_api_response
        mock_get.return_value = mock_response

        headers = {'Authorization': 'Bearer token123'}
        params = {'limit': 10, 'offset': 0}

        result = extract_from_api('https://api.test.com', headers=headers, params=params)
        self.assertIsInstance(result, list)

        mock_get.assert_called_once_with(
            'https://api.test.com',
            headers=headers,
            params=params,
            timeout=30
        )

if __name__ == '__main__':
    unittest.main()
