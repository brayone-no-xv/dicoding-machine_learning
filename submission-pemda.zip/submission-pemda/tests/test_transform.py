"""
Unit tests for the transform module
"""

import unittest
import pandas as pd
import numpy as np
import sys
import os
from datetime import datetime

sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'utils'))

from utils.transform import (
    clean_text_data,
    normalize_numeric_data,
    handle_missing_values,
    standardize_date_format,
    remove_duplicates,
    validate_data_types,
    transform_data_pipeline
)

class TestTransformModule(unittest.TestCase):

    def setUp(self):
        """Set up test fixtures"""
        self.sample_df = pd.DataFrame({
            'name': ['Product A', 'Product B', 'Product C'],
            'price': [10.5, 20.0, 15.75],
            'quantity': [100, 50, 75],
            'description': ['  Good product  ', 'Best!! product@', '  Average   ']
        })

        self.df_with_missing = pd.DataFrame({
            'name': ['Product A', None, 'Product C'],
            'price': [10.5, None, 15.75],
            'quantity': [100, 50, None]
        })

        self.df_with_duplicates = pd.DataFrame({
            'name': ['Product A', 'Product B', 'Product A'],
            'price': [10.5, 20.0, 10.5],
        })

    def test_clean_text_data_string(self):
        """Test text cleaning with string input"""
        dirty_text = "  Hello @#$World!  "
        result = clean_text_data(dirty_text)
        self.assertEqual(result, "Hello World")

    def test_clean_text_data_series(self):
        """Test text cleaning with pandas Series"""
        dirty_series = pd.Series(['  Text@#$  ', 'Another!!text  '])
        result = clean_text_data(dirty_series)
        self.assertIsInstance(result, pd.Series)
        self.assertEqual(result.iloc[0], 'Text')
        self.assertEqual(result.iloc[1], 'Anothertext')

    def test_clean_text_data_no_special_chars(self):
        """Test text cleaning without removing special characters"""
        dirty_text = "  Hello @#$World!  "
        result = clean_text_data(dirty_text, remove_special_chars=False)
        self.assertEqual(result, "Hello @#$World!")

    def test_normalize_numeric_data_success(self):
        """Test successful numeric normalization"""
        df = self.sample_df.copy()
        result = normalize_numeric_data(df, ['price', 'quantity'])

        self.assertTrue(result['price'].min() >= 0)
        self.assertTrue(result['price'].max() <= 1)
        self.assertTrue(result['quantity'].min() >= 0)
        self.assertTrue(result['quantity'].max() <= 1)

    def test_normalize_numeric_data_nonexistent_column(self):
        """Test numeric normalization with non-existent column"""
        df = self.sample_df.copy()
        result = normalize_numeric_data(df, ['nonexistent_column'])
        pd.testing.assert_frame_equal(result, df)

    def test_handle_missing_values_median_strategy(self):
        """Test missing value handling with median strategy"""
        result = handle_missing_values(self.df_with_missing, strategy='median')

        self.assertEqual(result.isnull().sum().sum(), 0)

        original_median = self.df_with_missing['price'].median()
        self.assertEqual(result['price'].iloc[1], original_median)

    def test_handle_missing_values_mean_strategy(self):
        """Test missing value handling with mean strategy"""
        result = handle_missing_values(self.df_with_missing, strategy='mean')

        self.assertEqual(result.isnull().sum().sum(), 0)

    def test_handle_missing_values_drop_strategy(self):
        """Test missing value handling with drop strategy"""
        result = handle_missing_values(self.df_with_missing, strategy='drop')

        self.assertEqual(len(result), 1)
        self.assertEqual(result.isnull().sum().sum(), 0)

    def test_handle_missing_values_custom_strategy(self):
        """Test missing value handling with custom values"""
        custom_values = {'name': 'Unknown', 'price': 0.0}
        result = handle_missing_values(
            self.df_with_missing,
            strategy='custom',
            custom_values=custom_values
        )

        self.assertEqual(result['name'].iloc[1], 'Unknown')
        self.assertEqual(result['price'].iloc[1], 0.0)

    def test_handle_missing_values_no_missing_data(self):
        """Test missing value handling with no missing data"""
        result = handle_missing_values(self.sample_df)
        pd.testing.assert_frame_equal(result, self.sample_df)

    def test_standardize_date_format_success(self):
        """Test successful date format standardization"""
        df_with_dates = pd.DataFrame({
            'date1': ['2023-01-15', '2023-02-20'],
            'date2': ['15/01/2023', '20/02/2023']
        })

        result = standardize_date_format(df_with_dates, ['date1', 'date2'])

        self.assertTrue(all(isinstance(date, str) for date in result['date1']))
        self.assertTrue(all(isinstance(date, str) for date in result['date2']))

    def test_standardize_date_format_nonexistent_column(self):
        """Test date standardization with non-existent column"""
        result = standardize_date_format(self.sample_df, ['nonexistent_date'])
        pd.testing.assert_frame_equal(result, self.sample_df)

    def test_remove_duplicates_success(self):
        """Test successful duplicate removal"""
        result = remove_duplicates(self.df_with_duplicates)

        self.assertEqual(len(result), 2)
        self.assertEqual(len(result['name'].unique()), 2)

    def test_remove_duplicates_no_duplicates(self):
        """Test duplicate removal with no duplicates"""
        result = remove_duplicates(self.sample_df)
        self.assertEqual(len(result), len(self.sample_df))

    def test_remove_duplicates_subset(self):
        """Test duplicate removal with subset of columns"""
        result = remove_duplicates(self.df_with_duplicates, subset=['name'])
        self.assertEqual(len(result), 2)

    def test_validate_data_types_success(self):
        """Test successful data type validation"""
        type_mapping = {
            'price': 'float64',
            'quantity': 'int64'
        }
        result = validate_data_types(self.sample_df, type_mapping)

        self.assertEqual(str(result['price'].dtype), 'float64')
        self.assertIn(str(result['quantity'].dtype), ['int64', 'Int64'])

    def test_validate_data_types_nonexistent_column(self):
        """Test data type validation with non-existent column"""
        type_mapping = {'nonexistent_column': 'int64'}
        result = validate_data_types(self.sample_df, type_mapping)
        pd.testing.assert_frame_equal(result, self.sample_df)

    def test_validate_data_types_datetime(self):
        """Test data type validation with datetime conversion"""
        df_with_dates = pd.DataFrame({
            'date_col': ['2023-01-15', '2023-02-20']
        })
        type_mapping = {'date_col': 'datetime64[ns]'}
        result = validate_data_types(df_with_dates, type_mapping)

        self.assertTrue(pd.api.types.is_datetime64_any_dtype(result['date_col']))

    def test_transform_data_pipeline_empty_dataframe(self):
        """Test transformation pipeline with empty dataframe"""
        empty_df = pd.DataFrame()
        config = {'handle_missing': True}
        result = transform_data_pipeline(empty_df, config)
        self.assertTrue(result.empty)

    def test_transform_data_pipeline_comprehensive(self):
        """Test comprehensive transformation pipeline"""
        config = {
            'handle_missing': True,
            'missing_strategy': 'median',
            'remove_duplicates': True,
            'clean_text': True,
            'text_columns': ['description'],
            'validate_types': True,
            'type_mapping': {
                'price': 'float64',
                'quantity': 'int64'
            }
        }

        test_df = pd.DataFrame({
            'name': ['Product A', 'Product B', None],
            'price': [10.5, None, 15.75],
            'quantity': [100, 50, 75],
            'description': ['  Good   ', 'Best!!@product', '  Average   ']
        })

        result = transform_data_pipeline(test_df, config)

        self.assertEqual(result.isnull().sum().sum(), 0)
        self.assertEqual(str(result['price'].dtype), 'float64')
        self.assertTrue(all('  ' not in str(desc) for desc in result['description']))

    def test_transform_data_pipeline_no_config(self):
        """Test transformation pipeline with empty config"""
        config = {}
        result = transform_data_pipeline(self.sample_df, config)
        pd.testing.assert_frame_equal(result, self.sample_df)

if __name__ == '__main__':
    unittest.main()
