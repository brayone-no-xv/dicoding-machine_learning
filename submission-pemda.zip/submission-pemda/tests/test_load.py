"""
Unit tests for the load module
"""

import unittest
import pandas as pd
import json
import os
import tempfile
import sqlite3
import sys
from unittest.mock import patch, mock_open, Mock

sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'utils'))

from utils.load import (
    save_to_csv,
    save_to_json,
    save_to_sqlite,
    append_to_existing_csv,
    validate_load_operation,
    load_data_pipeline,
    save_to_google_sheets,
    save_to_postgresql
)

class TestLoadModule(unittest.TestCase):

    def setUp(self):
        """Set up test fixtures"""
        self.sample_df = pd.DataFrame({
            'name': ['Product A', 'Product B', 'Product C'],
            'price': [10.5, 20.0, 15.75],
            'quantity': [100, 50, 75]
        })

        self.sample_data_dict = [
            {'name': 'Product A', 'price': 10.5, 'quantity': 100},
            {'name': 'Product B', 'price': 20.0, 'quantity': 50}
        ]

        self.temp_dir = tempfile.mkdtemp()

    def tearDown(self):
        """Clean up test fixtures"""
        import shutil
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_save_to_csv_success(self):
        """Test successful CSV saving"""
        csv_path = os.path.join(self.temp_dir, 'test_output.csv')
        result = save_to_csv(self.sample_df, csv_path)

        self.assertTrue(result)
        self.assertTrue(os.path.exists(csv_path))

        loaded_df = pd.read_csv(csv_path)
        self.assertEqual(len(loaded_df), len(self.sample_df))
        self.assertListEqual(list(loaded_df.columns), list(self.sample_df.columns))

    def test_save_to_csv_empty_dataframe(self):
        """Test CSV saving with empty dataframe"""
        empty_df = pd.DataFrame()
        csv_path = os.path.join(self.temp_dir, 'empty_test.csv')
        result = save_to_csv(empty_df, csv_path)

        self.assertTrue(result)
        self.assertTrue(os.path.exists(csv_path))

    def test_save_to_csv_invalid_path(self):
        """Test CSV saving with invalid path"""
        invalid_path = '/root/forbidden/test.csv'
        result = save_to_csv(self.sample_df, invalid_path)
        self.assertFalse(result)

    def test_save_to_csv_append_mode(self):
        """Test CSV saving in append mode"""
        csv_path = os.path.join(self.temp_dir, 'append_test.csv')

        result1 = save_to_csv(self.sample_df, csv_path)
        self.assertTrue(result1)

        result2 = save_to_csv(self.sample_df, csv_path, mode='a')
        self.assertTrue(result2)

        self.assertTrue(os.path.exists(csv_path))
        file_size = os.path.getsize(csv_path)
        self.assertGreater(file_size, 0)

    def test_save_to_json_dataframe(self):
        """Test JSON saving with DataFrame"""
        json_path = os.path.join(self.temp_dir, 'test_output.json')
        result = save_to_json(self.sample_df, json_path)

        self.assertTrue(result)
        self.assertTrue(os.path.exists(json_path))

        with open(json_path, 'r') as f:
            loaded_data = json.load(f)

        self.assertIsInstance(loaded_data, list)
        self.assertEqual(len(loaded_data), len(self.sample_df))

    def test_save_to_json_dict_data(self):
        """Test JSON saving with dictionary data"""
        json_path = os.path.join(self.temp_dir, 'dict_test.json')
        result = save_to_json(self.sample_data_dict, json_path)

        self.assertTrue(result)
        self.assertTrue(os.path.exists(json_path))

        with open(json_path, 'r') as f:
            loaded_data = json.load(f)

        self.assertEqual(loaded_data, self.sample_data_dict)

    def test_save_to_json_empty_dataframe(self):
        """Test JSON saving with empty dataframe"""
        empty_df = pd.DataFrame()
        json_path = os.path.join(self.temp_dir, 'empty_test.json')
        result = save_to_json(empty_df, json_path)

        self.assertTrue(result)
        self.assertTrue(os.path.exists(json_path))

        with open(json_path, 'r') as f:
            loaded_data = json.load(f)

        self.assertEqual(loaded_data, {})

    def test_save_to_json_invalid_path(self):
        """Test JSON saving with invalid path"""
        invalid_path = '/root/forbidden/test.json'
        result = save_to_json(self.sample_data_dict, invalid_path)
        self.assertFalse(result)

    def test_save_to_sqlite_success(self):
        """Test successful SQLite saving"""
        sqlite_path = os.path.join(self.temp_dir, 'test.db')
        table_name = 'products'

        result = save_to_sqlite(self.sample_df, sqlite_path, table_name)
        self.assertTrue(result)
        self.assertTrue(os.path.exists(sqlite_path))

        conn = sqlite3.connect(sqlite_path)
        cursor = conn.cursor()
        cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
        count = cursor.fetchone()[0]
        conn.close()

        self.assertEqual(count, len(self.sample_df))

    def test_save_to_sqlite_empty_dataframe(self):
        """Test SQLite saving with empty dataframe"""
        empty_df = pd.DataFrame({'col1': [], 'col2': []})
        sqlite_path = os.path.join(self.temp_dir, 'empty_test.db')
        table_name = 'empty_products'

        result = save_to_sqlite(empty_df, sqlite_path, table_name)
        self.assertTrue(result)

    def test_save_to_sqlite_append_mode(self):
        """Test SQLite saving in append mode"""
        sqlite_path = os.path.join(self.temp_dir, 'append_test.db')
        table_name = 'products'

        result1 = save_to_sqlite(self.sample_df, sqlite_path, table_name, if_exists='replace')
        self.assertTrue(result1)

        result2 = save_to_sqlite(self.sample_df, sqlite_path, table_name, if_exists='append')
        self.assertTrue(result2)

        conn = sqlite3.connect(sqlite_path)
        cursor = conn.cursor()
        cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
        count = cursor.fetchone()[0]
        conn.close()

        expected_rows = len(self.sample_df) * 2
        self.assertEqual(count, expected_rows)

    def test_append_to_existing_csv_new_file(self):
        """Test appending to CSV when file doesn't exist"""
        csv_path = os.path.join(self.temp_dir, 'new_append.csv')
        result = append_to_existing_csv(self.sample_df, csv_path)

        self.assertTrue(result)
        self.assertTrue(os.path.exists(csv_path))

    def test_append_to_existing_csv_existing_file(self):
        """Test appending to existing CSV file"""
        csv_path = os.path.join(self.temp_dir, 'existing_append.csv')

        self.sample_df.to_csv(csv_path, index=False)
        initial_size = os.path.getsize(csv_path)

        result = append_to_existing_csv(self.sample_df, csv_path)
        self.assertTrue(result)

        final_size = os.path.getsize(csv_path)
        self.assertGreater(final_size, initial_size)

    def test_validate_load_operation_success(self):
        """Test successful load operation validation"""
        csv_path = os.path.join(self.temp_dir, 'validation_test.csv')
        save_to_csv(self.sample_df, csv_path)

        result = validate_load_operation(csv_path, expected_rows=len(self.sample_df))
        self.assertTrue(result)

    def test_validate_load_operation_file_not_exists(self):
        """Test load validation with non-existent file"""
        result = validate_load_operation('non_existent_file.csv')
        self.assertFalse(result)

    def test_validate_load_operation_empty_file(self):
        """Test load validation with empty file"""
        empty_path = os.path.join(self.temp_dir, 'empty_validation.csv')
        with open(empty_path, 'w') as f:
            pass

        result = validate_load_operation(empty_path)
        self.assertFalse(result)

    def test_validate_load_operation_row_count_mismatch(self):
        """Test load validation with row count mismatch"""
        csv_path = os.path.join(self.temp_dir, 'mismatch_test.csv')
        save_to_csv(self.sample_df, csv_path)

        result = validate_load_operation(csv_path, expected_rows=100)
        self.assertTrue(result)

    def test_load_data_pipeline_empty_dataframe(self):
        """Test load pipeline with empty dataframe"""
        empty_df = pd.DataFrame()
        config = {'save_csv': True, 'csv_path': os.path.join(self.temp_dir, 'empty.csv')}

        result = load_data_pipeline(empty_df, config)
        self.assertIn('warning', result)
        self.assertEqual(result['warning'], 'empty_dataframe')

    def test_load_data_pipeline_csv_only(self):
        """Test load pipeline with CSV saving only"""
        config = {
            'save_csv': True,
            'csv_path': os.path.join(self.temp_dir, 'pipeline_test.csv')
        }

        result = load_data_pipeline(self.sample_df, config)
        self.assertIn('csv', result)
        self.assertTrue(result['csv'])

    def test_load_data_pipeline_multiple_formats(self):
        """Test load pipeline with multiple output formats"""
        config = {
            'save_csv': True,
            'csv_path': os.path.join(self.temp_dir, 'multi_test.csv'),
            'save_json': True,
            'json_path': os.path.join(self.temp_dir, 'multi_test.json'),
            'save_sqlite': True,
            'sqlite_path': os.path.join(self.temp_dir, 'multi_test.db'),
            'table_name': 'test_table'
        }

        result = load_data_pipeline(self.sample_df, config)

        self.assertTrue(result.get('csv', False))
        self.assertTrue(result.get('json', False))
        self.assertTrue(result.get('sqlite', False))

        self.assertTrue(os.path.exists(config['csv_path']))
        self.assertTrue(os.path.exists(config['json_path']))
        self.assertTrue(os.path.exists(config['sqlite_path']))

    def test_load_data_pipeline_no_operations(self):
        """Test load pipeline with no operations specified"""
        config = {}
        result = load_data_pipeline(self.sample_df, config)
        self.assertEqual(len(result), 0)

    @patch('utils.load.GOOGLE_SHEETS_AVAILABLE', False)
    def test_save_to_google_sheets_dependencies_not_available(self):
        """Test Google Sheets saving when dependencies are not installed"""
        result = save_to_google_sheets(
            self.sample_df,
            'Test Sheet',
            'Sheet1',
            'fake-credentials.json'
        )
        self.assertFalse(result)

    @patch('utils.load.GOOGLE_SHEETS_AVAILABLE', True)
    @patch('utils.load.os.path.exists')
    def test_save_to_google_sheets_credentials_not_found(self, mock_exists):
        """Test Google Sheets saving when credentials file doesn't exist"""
        mock_exists.return_value = False

        result = save_to_google_sheets(
            self.sample_df,
            'Test Sheet',
            'Sheet1',
            'nonexistent-credentials.json'
        )
        self.assertFalse(result)

    @patch('utils.load.GOOGLE_SHEETS_AVAILABLE', True)
    @patch('utils.load.os.path.exists')
    @patch('utils.load.Credentials.from_service_account_file')
    @patch('utils.load.gspread.authorize')
    def test_save_to_google_sheets_success(self, mock_authorize, mock_credentials, mock_exists):
        """Test successful Google Sheets saving"""
        mock_exists.return_value = True

        mock_gc = Mock()
        mock_spreadsheet = Mock()
        mock_worksheet = Mock()
        mock_spreadsheet.id = 'test-spreadsheet-id'

        mock_authorize.return_value = mock_gc
        mock_gc.open.return_value = mock_spreadsheet
        mock_spreadsheet.worksheet.return_value = mock_worksheet

        result = save_to_google_sheets(
            self.sample_df,
            'Test Sheet',
            'Sheet1',
            'credentials.json'
        )
        self.assertTrue(result)
        mock_worksheet.update.assert_called_once()

    @patch('utils.load.POSTGRESQL_AVAILABLE', False)
    def test_save_to_postgresql_dependencies_not_available(self):
        """Test PostgreSQL saving when dependencies are not installed"""
        connection_params = {
            'host': 'localhost',
            'database': 'test',
            'user': 'test',
            'password': 'test'
        }

        result = save_to_postgresql(self.sample_df, connection_params, 'test_table')
        self.assertFalse(result)

    @patch('utils.load.POSTGRESQL_AVAILABLE', True)
    def test_save_to_postgresql_missing_params(self):
        """Test PostgreSQL saving with missing connection parameters"""
        incomplete_params = {
            'host': 'localhost',
            'database': 'test'
        }

        result = save_to_postgresql(self.sample_df, incomplete_params, 'test_table')
        self.assertFalse(result)

    @patch('utils.load.POSTGRESQL_AVAILABLE', True)
    @patch('utils.load.create_engine')
    def test_save_to_postgresql_success(self, mock_create_engine):
        """Test successful PostgreSQL saving"""
        mock_engine = Mock()
        mock_connection = Mock()
        mock_result = Mock()
        mock_result.fetchone.return_value = [10]

        mock_create_engine.return_value = mock_engine
        mock_engine.connect.return_value.__enter__.return_value = mock_connection
        mock_connection.execute.return_value = mock_result

        with patch.object(self.sample_df, 'to_sql', return_value=3):
            connection_params = {
                'host': 'localhost',
                'database': 'test',
                'user': 'test',
                'password': 'test'
            }

            result = save_to_postgresql(self.sample_df, connection_params, 'test_table')
            self.assertTrue(result)

    @patch('utils.load.POSTGRESQL_AVAILABLE', True)
    @patch('utils.load.create_engine')
    def test_save_to_postgresql_connection_error(self, mock_create_engine):
        """Test PostgreSQL saving with connection error"""
        mock_create_engine.side_effect = Exception("Connection failed")

        connection_params = {
            'host': 'localhost',
            'database': 'test',
            'user': 'test',
            'password': 'test'
        }

        result = save_to_postgresql(self.sample_df, connection_params, 'test_table')
        self.assertFalse(result)

    def test_load_data_pipeline_google_sheets_enabled(self):
        """Test load pipeline with Google Sheets enabled"""
        config = {
            'save_google_sheets': True,
            'spreadsheet_name': 'Test Pipeline Data',
            'worksheet_name': 'Data',
            'google_credentials_path': 'test-credentials.json'
        }

        with patch('utils.load.save_to_google_sheets', return_value=True):
            result = load_data_pipeline(self.sample_df, config)
            self.assertIn('google_sheets', result)
            self.assertTrue(result['google_sheets'])

    def test_load_data_pipeline_postgresql_enabled(self):
        """Test load pipeline with PostgreSQL enabled"""
        config = {
            'save_postgresql': True,
            'postgresql_params': {
                'host': 'localhost',
                'database': 'test',
                'user': 'test',
                'password': 'test'
            },
            'postgresql_table_name': 'test_table'
        }

        with patch('utils.load.save_to_postgresql', return_value=True):
            result = load_data_pipeline(self.sample_df, config)
            self.assertIn('postgresql', result)
            self.assertTrue(result['postgresql'])

    def test_load_data_pipeline_postgresql_no_params(self):
        """Test load pipeline with PostgreSQL enabled but no connection params"""
        config = {
            'save_postgresql': True,
        }

        result = load_data_pipeline(self.sample_df, config)
        self.assertIn('postgresql', result)
        self.assertFalse(result['postgresql'])

if __name__ == '__main__':
    unittest.main()
